# Import the random module
import random

# CTS 285
# M2HW1 - Answer Checker
# Kent Jones
# 9/22/23

# Declaring Variables
num1 = random.randint(0, 9) # Num ranged between 0 and 20
num2 = random.randint(0, 9) # Num ranged between 0 and 20
sum = num1 + num2
wrongGuess = 0 # Tracks user guesses
repeat = False # While loop key

# Check if the guess is correct
while repeat == False: 
  print(num1, ' + ', num2, ' = ', '?')
  guess = int(input('What is the answer?: '))
  if wrongGuess == 3: # After third strike, display answer
      print('The Correct answer is ', sum)
      repeat = True
  if guess == sum:
    print('C O R R E C T')
    repeat = True
  else:
    print('E E E E')
    wrongGuess += 1
  